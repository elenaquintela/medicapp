<?php
  $perfil = $inv->perfil;
  $invitador = $inv->invitador;
?>
<!DOCTYPE html>
<html lang="es">
  <body style="font-family: Arial, Helvetica, sans-serif; line-height:1.5; color:#222">
    <p>Hola,</p>

    <p>
      <?php echo e($invitador->nombre ?? $invitador->email); ?> te ha invitado a gestionar el perfil
      <strong><?php echo e($perfil->nombre_paciente); ?></strong> en MedicApp.
    </p>

    <p>Para aceptar la invitación, haz clic aquí:</p>
    <p>
      <a href="<?php echo e($link); ?>"><?php echo e($link); ?></a>
    </p>

    <p>
      Si ya tienes cuenta, inicia sesión con este email (<?php echo e($inv->email); ?>).<br>
      Si no tienes, podrás crearla y se aceptará la invitación automáticamente.
    </p>

    <?php if($inv->expires_at): ?>
      <p>Este enlace caduca el <?php echo e($inv->expires_at->format('d/m/Y H:i')); ?>.</p>
    <?php endif; ?>

    <p>Gracias,<br>Equipo MedicApp</p>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\a23elenaqb\medicapp\resources\views/emails/invitacion_perfil.blade.php ENDPATH**/ ?>