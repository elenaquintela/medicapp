<?php $__env->startSection('content'); ?>
<div class="flex items-center justify-center min-h-screen relative">
    <div class="flex w-full max-w-6xl bg-[#0C1222] rounded-lg shadow-lg overflow-hidden">
        <div class="w-1/2 p-12 flex flex-col justify-center space-y-6">

            <div class="shrink-0 flex items-center space-x-3">
                <img src="<?php echo e(asset('logo.png')); ?>" alt="Logo MedicApp" class="w-20 h-16">
                <span class="text-6xl font-bold">MedicApp</span>
            </div>
            <h2 class="text-3xl font-bold">Tu medicación, siempre a tiempo</h2>

            <p class="text-xl leading-relaxed text-center">
                MedicApp te recuerda cada toma,<br>
                organiza tus <span class="text-yellow-300">citas médicas</span> y guarda <br>
                todo tu <span class="text-yellow-300">tratamiento</span> en un solo lugar…<br>
                para que tú solo te dediques a <span class="text-yellow-300">vivir</span>.
            </p><br>

            <button class="text-center mt-6">
                <a href="<?php echo e(route('register')); ?>"
                   class="bg-yellow-300 text-[#0C1222] font-bold py-3 px-10 rounded-full w-fit hover:bg-yellow-200 transition">
                    Comenzar
                </a>
            </button>
        </div>

        <div class="w-1/2 p-12 flex flex-col justify-center border-4 border-yellow-300 rounded-r-lg">
            <h2 class="text-xl text-center mb-1">¿Ya tiene una cuenta?</h2>
            <h3 class="text-2xl font-bold text-center mb-6">Iniciar sesión</h3>

            <form method="POST" action="<?php echo e(route('login')); ?>" class="space-y-4">
                <?php echo csrf_field(); ?>

                <div>
                    <label for="email" class="block mb-1 font-semibold">Correo electrónico</label>
                    <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus
                           class="w-full px-4 py-2 border border-gray-300 rounded shadow-sm text-[#0C1222] focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label for="password" class="block mb-1 font-semibold">Contraseña</label>
                    <input id="password" type="password" name="password" required
                           class="w-full px-4 py-2 border border-gray-300 rounded shadow-sm text-[#0C1222] focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="text-center mt-6">
                    <button type="submit"
                            class="bg-yellow-300 text-[#0C1222] font-bold px-10 py-3 rounded-full hover:bg-yellow-200 transition">
                        Acceder
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.welcome', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\a23elenaqb\medicapp\resources\views/auth/welcome.blade.php ENDPATH**/ ?>