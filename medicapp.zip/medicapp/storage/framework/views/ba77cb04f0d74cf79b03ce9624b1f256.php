

<?php $__env->startSection('title', 'Nuevo tratamiento – MedicApp'); ?>

<?php $__env->startSection('content'); ?>
<main class="flex-grow flex items-center justify-center">
    <div class="w-full max-w-2xl px-8">
        <h2 class="text-3xl font-bold text-center mb-10">Nuevo tratamiento</h2>

        <form method="POST" action="<?php echo e(route('tratamiento.store')); ?>" class="space-y-6">
            <?php echo csrf_field(); ?>

            <!-- Causa del tratamiento -->
            <div>
                <label for="causa" class="block mb-1 text-lg">Causa de tratamiento</label>
                <input id="causa" name="causa" type="text" required
                       class="w-full px-4 py-3 border border-gray-300 rounded text-[#0C1222] focus:outline-none focus:ring-2 focus:ring-blue-400">
                <?php $__errorArgs = ['causa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Botón -->
            <div class="text-center mt-8">
                <button type="submit" name="accion" value="done"
                        class="bg-yellow-300 text-[#0C1222] font-bold text-lg px-10 py-3 rounded-full hover:bg-yellow-200 transition">
                    Crear tratamiento
                </button>
            </div>
        </form>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\a23elenaqb\medicapp\resources\views/tratamiento/create.blade.php ENDPATH**/ ?>