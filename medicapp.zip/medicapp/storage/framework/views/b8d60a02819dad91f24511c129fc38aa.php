<?php if (isset($component)) { $__componentOriginal434acb839dbe43978da5be1a6bab0531 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal434acb839dbe43978da5be1a6bab0531 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.authenticated','data' => ['perfilesUsuario' => $perfilesUsuario,'perfilActivo' => $perfilActivo]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.authenticated'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['perfilesUsuario' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($perfilesUsuario),'perfilActivo' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($perfilActivo)]); ?>
    <div class="px-10 pt-6 h-full">

        <!-- Título centrado -->
        <h2 class="text-3xl font-bold mb-10 text-center">Nueva cita</h2>

        <form action="<?php echo e(route('cita.store')); ?>" method="POST"
              class="mx-auto w-[75%] grid grid-cols-1 md:grid-cols-2 gap-10 items-start">
            <?php echo csrf_field(); ?>

            <!-- Columna izquierda -->
            <div class="flex flex-col gap-6">
                <!-- Fecha -->
                <div class="flex items-center gap-4">
                    <label class="w-24 text-white">Fecha</label>
                    <input type="date" name="fecha" required
                        class="p-3 rounded-md text-black text-sm" />
                </div>

                <!-- Hora -->
                <div class="flex items-center gap-4">
                    <label class="w-32 text-white">Hora</label>
                    <div class="flex gap-3 w-full">
                        <input type="time" name="hora_inicio" required
                            class="p-2 rounded-md text-black text-sm w-[90px]">
                        <span class="text-white">-</span>
                        <input type="time" name="hora_fin"
                            class="p-2 rounded-md text-black text-sm w-[90px]">
                    </div>
                </div>

                <!-- Lugar -->
                <div class="flex items-center gap-4">
                    <label class="w-32 text-white">Lugar</label>
                    <input type="text" name="ubicacion" required
                        class="w-full p-3 rounded-md text-black text-sm"
                        placeholder="Centro de salud de Fontiñas">
                </div>

                <!-- Motivo -->
                <div class="flex items-center gap-4">
                    <label class="w-32 text-white">Motivo</label>
                    <input type="text" name="motivo" required
                        class="w-full p-3 rounded-md text-black text-sm"
                        placeholder="Renovación de Alta">
                </div>

                <!-- Especialidad -->
                <div class="flex items-center gap-4">
                    <label for="especialidad" class="w-32 text-white">Especialidad</label>
                    <div class="w-full">
                        <select name="especialidad" id="especialidad"
                            class="w-full p-3 rounded-md text-black text-sm"
                            onchange="mostrarInputEspecialidad(this)">
                            <option value="">Seleccione una especialidad</option>
                            <?php $__currentLoopData = $especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $esp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($esp); ?>"><?php echo e($esp); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <option value="otra">Otra</option>
                        </select>

                        <input type="text" name="especialidad_otra" id="input-especialidad-otra"
                            class="w-full mt-2 p-3 rounded-md text-black text-sm hidden"
                            placeholder="Especifique la especialidad" />
                    </div>
                </div>
            </div>

            <!-- Columna derecha -->
            <div class="flex flex-col gap-6">

                <!-- Observaciones -->
                <div class="flex flex-col gap-2">
                    <label class="text-white">Observaciones</label>
                    <textarea name="observaciones" rows="6"
                        class="w-full p-3 rounded-md text-black text-sm resize-none"
                        placeholder="Añade información adicional si es necesario..."></textarea>
                </div>

                <!-- Recordatorio -->
                <div class="flex items-center gap-4">
                    <label class="text-white">Notifícame</label>
                    <input type="checkbox" name="recordatorio" value="1"
                        class="w-6 h-6 text-green-500 accent-green-500">
                </div>
            </div>

            <!-- Botón Crear -->
            <div class="md:col-span-2 flex justify-center mt-6">
                <button type="submit"
                    class="bg-yellow-200 hover:bg-yellow-300 text-black font-bold py-3 px-10 rounded-full text-lg shadow-md">
                    Crear cita
                </button>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal434acb839dbe43978da5be1a6bab0531)): ?>
<?php $attributes = $__attributesOriginal434acb839dbe43978da5be1a6bab0531; ?>
<?php unset($__attributesOriginal434acb839dbe43978da5be1a6bab0531); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal434acb839dbe43978da5be1a6bab0531)): ?>
<?php $component = $__componentOriginal434acb839dbe43978da5be1a6bab0531; ?>
<?php unset($__componentOriginal434acb839dbe43978da5be1a6bab0531); ?>
<?php endif; ?>

<script>
function mostrarInputEspecialidad(select) {
    const input = document.getElementById('input-especialidad-otra');
    if (select.value === 'otra') {
        input.classList.remove('hidden');
    } else {
        input.classList.add('hidden');
    }
}
</script>
<?php /**PATH C:\xampp\htdocs\a23elenaqb\medicapp\resources\views/cita/create.blade.php ENDPATH**/ ?>