<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Elija su plan – MedicApp</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-[#0C1222] text-white min-h-screen font-sans flex flex-col justify-between">

    <!-- Header -->
    <?php if (isset($component)) { $__componentOriginalfd1f218809a441e923395fcbf03e4272 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfd1f218809a441e923395fcbf03e4272 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfd1f218809a441e923395fcbf03e4272)): ?>
<?php $attributes = $__attributesOriginalfd1f218809a441e923395fcbf03e4272; ?>
<?php unset($__attributesOriginalfd1f218809a441e923395fcbf03e4272); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfd1f218809a441e923395fcbf03e4272)): ?>
<?php $component = $__componentOriginalfd1f218809a441e923395fcbf03e4272; ?>
<?php unset($__componentOriginalfd1f218809a441e923395fcbf03e4272); ?>
<?php endif; ?>

    <main class="flex-grow flex flex-col items-center px-4 py-12">
        <h2 class="text-3xl font-bold text-center mb-12 uppercase tracking-wide">
            Elija un plan para su cuenta
        </h2>

        <div class="overflow-x-auto w-full max-w-6xl">
            <table class="table-auto w-full text-lg">
                <thead>
                    <tr class="text-left border-b border-white">
                        <th class="py-4 px-6"></th>
                        <th class="py-4 px-6 text-center text-yellow-300 text-xl font-bold align-middle">
                            Estándar<br><span class="text-white text-sm">GRATIS</span>
                        </th>
                        <th class="py-4 px-6 text-center text-blue-300 text-xl font-bold align-middle">
                            Premium<br><span class="text-white text-sm">10 €/MES</span>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $features = [
                            'Creación de múltiples perfiles' => [true, true],
                            'Gestión de tratamientos y citas médicas' => [true, true],
                            'Configuración de alertas y recordatorios' => [true, true],
                            'Soporte multiusuario (invite a familiares y cuidadores a gestionar su perfil)' => [false, true],
                            'Generación y exportación de informes personalizados' => [false, true],
                            'Sincronización de citas médicas con Google Calendar' => [false, true],
                        ];
                    ?>
            
                    <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desc => [$std, $prem]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-t border-white">
                        <td class="py-4 px-6"><?php echo e($desc); ?></td>
                        <td class="py-4 px-6 text-center"><?php echo $std ? '✅' : '❌'; ?></td>
                        <td class="py-4 px-6 text-center"><?php echo $prem ? '✅' : '❌'; ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
                    <tr>
                        <td></td>
                        <!-- Botón para plan Estándar -->
    <td class="py-8 px-6 text-center">
        <form method="POST" action="<?php echo e(route('planes.store')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="rol_global" value="estandar">
            <button type="submit"
                class="inline-block bg-yellow-200 text-[#0C1222] font-bold px-8 py-3 rounded hover:bg-yellow-300 transition">
                SELECCIONAR
            </button>
        </form>
    </td>

    <!-- Botón para plan Premium -->
    <td class="py-8 px-6 text-center">
        <form method="POST" action="<?php echo e(route('planes.store')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="rol_global" value="premium">
            <button type="submit"
                class="inline-block bg-blue-300 text-[#0C1222] font-bold px-8 py-3 rounded hover:bg-blue-200 transition">
                SELECCIONAR
            </button>
        </form>
    </td>
                    </tr>
                </tbody>
            </table>
            
        </div>
    </main>

    <!-- Footer -->
    <?php if (isset($component)) { $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $attributes; } ?>
<?php $component = App\View\Components\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Footer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $attributes = $__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $component = $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\a23elenaqb\medicapp\resources\views/account/planes.blade.php ENDPATH**/ ?>