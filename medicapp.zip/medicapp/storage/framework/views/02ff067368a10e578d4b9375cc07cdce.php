<?php $__env->startSection('title', 'Citas médicas – MedicApp'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $rol = Auth::user()->rol_global;
?>

<div class="flex flex-col px-10 pt-6 h-full">
    <h2 class="text-3xl font-bold mb-8 text-center">Citas médicas</h2>
    <div class="flex items-center gap-3 mb-6 w-full max-w-[85%]">
        <img src="<?php echo e(asset('filtro.png')); ?>" alt="Filtro"
             class="h-12 aspect-auto object-contain brightness-0 invert" />

        <input type="text"
               id="filtro-citas"
               class="w-full p-3 rounded-md text-black placeholder-gray-600 text-sm"
               placeholder="Filtre por fecha, hora, especialista-lugar, motivo o creador" />
    </div>

    <div class="flex w-full items-start">
        <div class="max-w-[85%] w-full overflow-x-auto mx-auto">
            <table class="w-full text-sm text-white border border-white">
                <thead class="bg-blue-400 text-black uppercase text-center">
                    <tr>
                        <th class="py-3 px-4">Fecha</th>
                        <th class="py-3 px-4">Hora</th>
                        <th class="py-3 px-4">Especialista - Lugar</th>
                        <th class="py-3 px-4">Motivo</th>
                        <th class="py-3 px-4">Observaciones</th>
                        <th class="py-3 px-4">Creado por</th>
                        <th class="py-3 px-4">Editar</th>
                    </tr>
                </thead>
                <tbody id="tabla-citas" class="text-center">
                    <?php $__empty_1 = true; $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="border-t border-white cita-fila">
                            <td class="py-3"><?php echo e(\Carbon\Carbon::parse($cita->fecha)->format('d / m / Y')); ?></td>
                            <td class="py-3"><?php echo e(\Carbon\Carbon::parse($cita->hora_inicio)->format('H:i')); ?></td>
                            <td class="py-3">
                                <?php echo e($cita->especialidad ? $cita->especialidad . ' - ' : ''); ?>

                                <?php echo e($cita->ubicacion); ?>

                            </td>
                            <td class="py-3"><?php echo e($cita->motivo); ?></td>
                            <td class="py-3"><?php echo e($cita->observaciones); ?></td>
                            <td class="py-3"><?php echo e($cita->usuarioCreador->nombre ?? 'Desconocido'); ?></td>
                            <td class="py-3">
                                <a href="<?php echo e(route('cita.edit', $cita->id_cita)); ?>" class="hover:opacity-80 inline-block">
                                    <img src="<?php echo e(asset('editar.png')); ?>" alt="Editar" class="w-6 h-6 object-contain invert mx-auto">
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="py-4 text-center text-gray-300">No hay citas registradas.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="w-[15%] flex flex-col items-center justify-center gap-6">
            <a href="<?php echo e(route('cita.create')); ?>"
               class="bg-green-400 hover:bg-green-500 text-black rounded-full w-20 h-20 flex items-center justify-center shadow-lg">
                <svg xmlns="http://www.w3.org/2000/svg" class="w-12 h-12" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 5v14m-7-7h14" />
                </svg>
            </a>
            <?php if($rol === 'premium' && $citas->isNotEmpty()): ?>
                <form action="<?php echo e(route('google.syncAll')); ?>" method="POST" class="w-20 h-20">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="perfil_id" value="<?php echo e($citas->first()->id_perfil); ?>">
                    <button type="submit" class="w-full h-full hover:opacity-90 transition" title="Sincronizar todas las citas del perfil activo">
                        <img src="<?php echo e(asset('google-sync.png')); ?>" alt="Sync Google Calendar" class="w-full h-full object-contain">
                    </button>
                </form>
            <?php elseif($rol === 'premium' && $citas->isEmpty()): ?>
                <div class="w-20 h-20 opacity-50 cursor-not-allowed" title="No hay citas que sincronizar">
                    <img src="<?php echo e(asset('google-sync.png')); ?>" alt="Sync Google Calendar" class="w-full h-full object-contain grayscale">
                </div>
            <?php else: ?>
                <div class="w-20 h-20 opacity-50 cursor-not-allowed" title="Solo disponible en el plan Premium">
                    <img src="<?php echo e(asset('google-sync.png')); ?>" alt="Sync Google Calendar" class="w-full h-full object-contain grayscale">
                </div>
            <?php endif; ?>
        </div>

    </div>
</div>

<style>
    .resaltado {
        background-color: #bfdbfe;
        color: #0c1222;
        font-weight: bold;
        padding: 0 2px;
        border-radius: 3px;
    }
</style>

<script>
document.addEventListener('DOMContentLoaded', function () {
  const input = document.getElementById('filtro-citas');
  const filas = document.querySelectorAll('.cita-fila');
  filas.forEach(fila => {
    fila.querySelectorAll('td').forEach(td => {
      const esAccion = td.querySelector('a,button,form,img,svg');
      if (!esAccion && !td.hasAttribute('data-original-html')) {
        td.setAttribute('data-original-html', td.innerHTML);
      }
    });
  });

  function resaltarEnCelda(td, texto) {
    const htmlBase = td.getAttribute('data-original-html');
    if (!htmlBase) return;
    if (!texto) { td.innerHTML = htmlBase; return; }

    const regex = new RegExp(`(${texto.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
    td.innerHTML = htmlBase.replace(regex, '<span class="resaltado">$1</span>');
  }

  input.addEventListener('input', function () {
    const texto = (input.value || '').toLowerCase().trim();

    filas.forEach(fila => {
      const celdas = fila.querySelectorAll('td');
      let coincide = false;

      celdas.forEach(td => {
        const esAccion = td.querySelector('a,button,form,img,svg');
        const contenido = (td.textContent || '').toLowerCase();

        if (!esAccion) {
          if (texto && contenido.includes(texto)) {
            coincide = true;
            resaltarEnCelda(td, texto);
          } else {
            resaltarEnCelda(td, '');
            if (texto && !coincide && contenido.includes(texto)) coincide = true;
          }
        } else {
          if (texto && contenido.includes(texto)) coincide = true;
        }
      });

      fila.style.display = (coincide || texto === '') ? '' : 'none';
    });
  });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\a23elenaqb\medicapp\resources\views/cita/index.blade.php ENDPATH**/ ?>