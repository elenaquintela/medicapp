<header class="bg-[#0C1222] py-4 px-6 flex items-center shadow-md">
    <img src="<?php echo e(asset('logo.png')); ?>" alt="Logo MedicApp" class="w-20 h-auto mr-3">
    <h1 class="text-4xl font-bold text-white">MedicApp</h1>
</header><?php /**PATH C:\xampp\htdocs\a23elenaqb\medicapp\resources\views/components/header.blade.php ENDPATH**/ ?>