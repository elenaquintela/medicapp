<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['perfilesUsuario', 'perfilActivo' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['perfilesUsuario', 'perfilActivo' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $usuario = Auth::user();
    $rol = $usuario->rol_global;
?>

<header class="bg-[#0C1222] text-white py-4 px-6 flex items-center justify-between shadow-md">

    <a href="<?php echo e(route('dashboard')); ?>" class="shrink-0 flex items-center space-x-3 hover:opacity-90 transition">
        <img src="<?php echo e(asset('logo.png')); ?>" alt="Logo MedicApp" class="w-20 h-auto">
        <span class="text-4xl font-bold text-white">MedicApp</span>
    </a>

    <div class="flex items-center space-x-6">
        <?php if (isset($component)) { $__componentOriginaldf8083d4a852c446488d8d384bbc7cbe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown','data' => ['align' => 'right','width' => '48']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['align' => 'right','width' => '48']); ?>
             <?php $__env->slot('trigger', null, []); ?> 
                <button class="bg-yellow-300 text-[#0C1222] font-semibold px-4 py-2 rounded-full shadow hover:bg-yellow-200 transition inline-flex items-center">
                    <span><?php echo e($perfilActivo->nombre_paciente ?? 'Perfil actual'); ?></span>
                    <svg class="ml-2 w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M5.23 7.21a.75.75 0 011.06.02L10 10.939l3.71-3.71a.75.75 0 011.08 1.04l-4.25 4.25a.75.75 0 01-1.08 0l-4.25-4.25a.75.75 0 01.02-1.06z"/>
                    </svg>
                </button>
             <?php $__env->endSlot(); ?>

             <?php $__env->slot('content', null, []); ?> 
                <?php if(count($perfilesUsuario) <= 1): ?>
                    <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('perfil.create', ['fromDashboard' => 1])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('perfil.create', ['fromDashboard' => 1]))]); ?>
                        Crear nuevo perfil
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
                <?php else: ?>
                    <?php $__currentLoopData = $perfilesUsuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perfil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form method="POST" action="<?php echo e(route('perfil.seleccionar')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id_perfil" value="<?php echo e($perfil->id_perfil); ?>">
                            <input type="hidden" name="redirect_to" value="<?php echo e(request()->fullUrl()); ?>">
                            <button type="submit" class="w-full text-left px-4 py-2 text-sm hover:bg-gray-100 dark:hover:bg-gray-700">
                                <?php echo e($perfil->nombre_paciente); ?>

                            </button>
                        </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <hr class="my-2 border-gray-300">

                    <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('perfil.create', ['fromDashboard' => 1])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('perfil.create', ['fromDashboard' => 1]))]); ?>
                        Nuevo perfil
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
                <?php endif; ?>
             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe)): ?>
<?php $attributes = $__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe; ?>
<?php unset($__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldf8083d4a852c446488d8d384bbc7cbe)): ?>
<?php $component = $__componentOriginaldf8083d4a852c446488d8d384bbc7cbe; ?>
<?php unset($__componentOriginaldf8083d4a852c446488d8d384bbc7cbe); ?>
<?php endif; ?>

        <div class="relative">
            <button type="button" class="relative inline-flex items-center" data-bell title="Notificaciones">
                <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6 text-orange-400" fill="currentColor" viewBox="0 0 16 16">
                    <path d="M8 16a2 2 0 0 0 2-2H6a2 2 0 0 0 2 2zm.104-14.684a1.5 1.5 0 1 0-1.208 0A5.002 5.002 0 0 0 3 6c0 1.098-.628 2.082-1.579 2.563A.5.5 0 0 0 1.5 9.5h13a.5.5 0 0 0 .079-.937A2.993 2.993 0 0 1 13 6a5.002 5.002 0 0 0-4.896-4.684z"/>
                </svg>
                <span data-bell-badge class="hidden absolute -top-1 -right-1 bg-red-500 text-white text-[10px] leading-none px-1.5 py-0.5 rounded-full">0</span>
            </button>

            <div data-bell-menu class="hidden absolute right-0 mt-2 w-80 bg-[#0C1222] border border-gray-700 rounded-xl shadow-xl overflow-hidden z-50">
                <div class="px-4 py-3 border-b border-gray-700 flex items-center justify-between">
                    <span class="text-sm font-semibold">Tomas</span>
                    <button type="button" data-bell-markall class="text-xs text-blue-300 hover:text-blue-200">Marcar todas como leídas</button>
                </div>

                <div data-bell-empty class="hidden px-4 py-8 text-sm text-gray-400 text-center">
                    No hay notificaciones que mostrar
                </div>
                <ul data-bell-list class="max-h-64 overflow-auto divide-y divide-gray-800"></ul>
                <div data-bell-recent-header class="px-4 py-2 text-xs opacity-70 border-t border-gray-800">Recientes</div>
                <ul data-bell-list-recent class="max-h-40 overflow-auto divide-y divide-gray-800"></ul>
            </div>
        </div>

        <?php
            $user = Auth::user();
            $isPremium = $user->rol_global === 'premium';
        ?>

        <?php if (isset($component)) { $__componentOriginaldf8083d4a852c446488d8d384bbc7cbe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown','data' => ['align' => 'right','width' => '48']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['align' => 'right','width' => '48']); ?>
             <?php $__env->slot('trigger', null, []); ?> 
                <button
                    class="inline-flex items-center px-4 py-2 border border-transparent rounded-full shadow transition
                    <?php echo e($isPremium ? 'bg-[#7fb0dd] text-white hover:bg-[#6aa1d0]' : 'bg-yellow-300 text-[#0C1222] hover:bg-yellow-200'); ?>">
                    <span class="font-bold mr-2"><?php echo e($user->nombre ?? $user->name); ?></span>
                    <span class="text-sm font-semibold <?php echo e($isPremium ? 'text-white' : 'text-[#0C1222]'); ?>">
                        <?php echo e(ucfirst($user->rol_global)); ?>

                    </span>
                    <svg class="ml-2 w-4 h-4 <?php echo e($isPremium ? 'text-white' : 'text-[#0C1222]'); ?>" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd"
                            d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                            clip-rule="evenodd" />
                    </svg>
                </button>
             <?php $__env->endSlot(); ?>

             <?php $__env->slot('content', null, []); ?> 
                <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('account.edit')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('account.edit'))]); ?>
                    Cuenta
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>

                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => ''.e(route('logout')).'','onclick' => 'event.preventDefault(); this.closest(\'form\').submit();']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('logout')).'','onclick' => 'event.preventDefault(); this.closest(\'form\').submit();']); ?>
                        Salir
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
                </form>
             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe)): ?>
<?php $attributes = $__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe; ?>
<?php unset($__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldf8083d4a852c446488d8d384bbc7cbe)): ?>
<?php $component = $__componentOriginaldf8083d4a852c446488d8d384bbc7cbe; ?>
<?php unset($__componentOriginaldf8083d4a852c446488d8d384bbc7cbe); ?>
<?php endif; ?>
    </div>
</header>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
  const bell = document.querySelector('[data-bell]');
  const badge = document.querySelector('[data-bell-badge]');
  const menu = document.querySelector('[data-bell-menu]');
  const list = document.querySelector('[data-bell-list]');
  const listRecent = document.querySelector('[data-bell-list-recent]');
  const markAllBtn = document.querySelector('[data-bell-markall]');
  const emptyBox = document.querySelector('[data-bell-empty]');
  const recentHeader = document.querySelector('[data-bell-recent-header]');

  if (!bell || !badge || !menu || !list || !listRecent) return;

  const ORIGINAL_TITLE = document.title;
  let menuOpen = false;
  let currentUnreadCount = 0;
  let currentMaxId = 0;   
  let lastSeenMaxId = 0;  

  function applyIndicators() {
    const hasUnseen = currentUnreadCount > 0 && currentMaxId > lastSeenMaxId && !menuOpen;

    if (hasUnseen) {
      badge.textContent = currentUnreadCount;
      badge.classList.remove('hidden');
      document.title = `(${currentUnreadCount}) ${ORIGINAL_TITLE}`;
    } else {
      badge.textContent = '';
      badge.classList.add('hidden');
      document.title = ORIGINAL_TITLE;
    }
  }

  function showEmptyState() {
    if (emptyBox) emptyBox.classList.remove('hidden');
    list.innerHTML = '';
    listRecent.innerHTML = '';
    list.classList.add('hidden');
    listRecent.classList.add('hidden');
    if (recentHeader) recentHeader.classList.add('hidden');
  }

  function showLists() {
    if (emptyBox) emptyBox.classList.add('hidden');
    list.classList.remove('hidden');
    listRecent.innerHTML = '';
    listRecent.classList.add('hidden');
    if (recentHeader) recentHeader.classList.add('hidden');
  }

  function render(arr, container) {
    container.innerHTML = '';
    if (!arr || !arr.length) return;
    arr.forEach(n => {
      const li = document.createElement('li');
      li.className = 'px-4 py-3 hover:bg-gray-800/60';
      li.innerHTML = `
        <div class="text-sm font-medium">${n.titulo}</div>
        <div class="text-xs opacity-80">${n.msg || ''}</div>
        <div class="text-[11px] opacity-60 mt-1">${n.hora}</div>
      `;
      container.appendChild(li);
    });
  }

  async function fetchData(markSeen = false) {
    try {
      const url = new URL('<?php echo e(route('notificaciones.index')); ?>', window.location.origin);
      if (markSeen) url.searchParams.set('mark_seen', '1');

      const res = await fetch(url.toString(), {
        headers: { 'X-Requested-With': 'XMLHttpRequest' },
        cache: 'no-store'
      });
      if (!res.ok) {
        currentUnreadCount = 0;
        currentMaxId = 0;
        showEmptyState();
        applyIndicators();
        return { count: 0, items: [] };
      }

      const data = await res.json();
      const unread = Array.isArray(data.unread) ? data.unread : [];
      const count = data.unread_count || unread.length;

      currentUnreadCount = count;
      currentMaxId = unread.reduce((mx, n) => Math.max(mx, Number(n.id) || 0), 0);

      if (menuOpen && currentMaxId > lastSeenMaxId) {
        lastSeenMaxId = currentMaxId;
      }

      if (count === 0) {
        showEmptyState();
      } else {
        showLists();
        render(unread, list);
      }

      applyIndicators();
      return { count, items: unread };
    } catch (e) {
      return { count: 0, items: [] };
    }
  }

  async function marcarTodasSilencioso() {
    try {
      const res = await fetch(`<?php echo e(route('notificaciones.leerTodas')); ?>`, {
        method: 'POST',
        headers: {
          'X-Requested-With': 'XMLHttpRequest',
          'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || ''
        }
      });
      return res.ok;
    } catch { return false; }
  }

  bell.addEventListener('click', async () => {
    const willOpen = menu.classList.contains('hidden');
    menu.classList.toggle('hidden');
    menuOpen = willOpen;

    if (willOpen) {
      await fetchData(true); 
      lastSeenMaxId = Math.max(lastSeenMaxId, currentMaxId);
      applyIndicators(); 
    } else {
      fetchData();
    }
  });

  document.addEventListener('click', (e) => {
    if (!menu.contains(e.target) && !bell.contains(e.target)) {
      if (!menu.classList.contains('hidden')) {
        menu.classList.add('hidden');
        menuOpen = false;
        fetchData();
      }
    }
  });

  if (markAllBtn) {
    markAllBtn.addEventListener('click', async () => {
      const ok = await marcarTodasSilencioso();
      if (ok) {
        currentUnreadCount = 0;
        lastSeenMaxId = Math.max(lastSeenMaxId, currentMaxId);
        showEmptyState();
        applyIndicators();
      }
    });
  }

  fetchData();
  const POLL_MS = 10000; 
  setInterval(fetchData, POLL_MS);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) fetchData(); });
  window.addEventListener('online', fetchData);
});
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\a23elenaqb\medicapp\resources\views/components/auth-header.blade.php ENDPATH**/ ?>