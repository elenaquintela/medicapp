<?php $__env->startSection('title', 'Nueva medicación – MedicApp'); ?>

<?php $__env->startSection('content'); ?>
<main class="flex-grow px-4 py-10 flex justify-center">
    <div class="w-full max-w-3xl pb-32">
        <h2 class="text-3xl font-bold text-center mb-10">
            Medicación para <?php echo e($tratamiento->causa); ?>

        </h2>
        <form method="POST"
              action="<?php echo e(isset($medicacion) ? route('medicacion.update', $medicacion->id_trat_med) : route('medicacion.store', ['tratamiento' => $tratamiento->id_tratamiento])); ?>"
              class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <?php echo csrf_field(); ?>
            <?php if(isset($medicacion)): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>

            <?php if(request('volver_a_index')): ?>
                <input type="hidden" name="volver_a_index" value="1">
            <?php endif; ?>
            <div class="space-y-4">
                <label class="block">
                    <span class="text-lg">Nombre</span>
                    <input name="nombre" type="text" required
                           value="<?php echo e(old('nombre', $medicacion->medicamento->nombre ?? '')); ?>"
                           class="mt-1 block w-full px-4 py-3 border border-gray-300 rounded text-[#0C1222]">
                </label>
                <label class="block">
                    <span class="text-lg">Presentación</span>
                    <select name="presentacion" required
                            class="mt-1 block w-full px-4 py-3 border border-gray-300 rounded text-[#0C1222] bg-white">
                        <?php $__currentLoopData = ['comprimidos','jarabe','gotas','inyeccion','pomada','parche','polvo','spray','otro']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($op); ?>" <?php if(old('presentacion', $medicacion->presentacion ?? '') === $op): ?> selected <?php endif; ?>>
                                <?php echo e(ucfirst($op)); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>     
                <label class="block">
                    <span class="text-lg">Inicio</span>
                    <input name="fecha_hora_inicio" type="datetime-local" required
                           value="<?php echo e(old('fecha_hora_inicio', isset($medicacion) ? \Carbon\Carbon::parse($medicacion->fecha_hora_inicio)->format('Y-m-d\TH:i') : '')); ?>"
                           class="mt-1 block w-full px-4 py-3 border border-gray-300 rounded text-[#0C1222]">
                </label>
                 <label class="block">
                    <span class="text-lg">Frecuencia (cada...)</span>
                    <input name="pauta_intervalo" type="number" required min="1"
                           value="<?php echo e(old('pauta_intervalo', $medicacion->pauta_intervalo ?? '')); ?>"
                           class="mt-1 block w-full px-4 py-3 border border-gray-300 rounded text-[#0C1222]">
                </label>
            </div>

            <div class="space-y-4">
                <label class="block">
                    <span class="text-lg">Vía</span>
                    <select name="via" required
                            class="mt-1 block w-full px-4 py-3 border border-gray-300 rounded text-[#0C1222] bg-white">
                        <?php $__currentLoopData = ['oral','topica','nasal','ocular','otica','intravenosa','intramuscular','subcutanea','rectal','inhalatoria','otro']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($op); ?>" <?php if(old('via', $medicacion->via ?? '') === $op): ?> selected <?php endif; ?>>
                                <?php echo e(ucfirst($op)); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>

                <label class="block">
                    <span class="text-lg">Indicación</span>
                    <input name="indicacion" type="text" placeholder="Dolor, náuseas ..." required
                           value="<?php echo e(old('indicacion', $medicacion->indicacion ?? '')); ?>"
                           class="mt-1 block w-full px-4 py-3 border border-gray-300 rounded text-[#0C1222]">
                </label>

                 <label class="block">
                    <span class="text-lg">Dosis</span>
                    <input name="dosis" type="text" placeholder="1g, 50mg ..." required
                           value="<?php echo e(old('dosis', $medicacion->dosis ?? '')); ?>"
                           class="mt-1 block w-full px-4 py-3 border border-gray-300 rounded text-[#0C1222]">
                </label>


                <label class="block">
                    <span class="text-lg">Unidad de tiempo</span>
                    <select name="pauta_unidad" required
                            class="mt-1 block w-full px-4 py-3 border border-gray-300 rounded text-[#0C1222] bg-white">
                        <?php $__currentLoopData = ['horas','dias','semanas','meses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($unidad); ?>" <?php if(old('pauta_unidad', $medicacion->pauta_unidad ?? '') === $unidad): ?> selected <?php endif; ?>>
                                <?php echo e(ucfirst($unidad)); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>
            </div>

            <label class="block col-span-2">
                    <span class="text-lg">Observaciones</span>
                    <textarea name="observaciones" rows="3"
                              class="mt-1 block w-full px-4 py-3 border border-gray-300 rounded text-[#0C1222]"><?php echo e(old('observaciones', $medicacion->observaciones ?? '')); ?></textarea>
            </label>

                <div class="col-span-2 mt-8 flex flex-wrap gap-4 justify-center">

                    <?php if(isset($medicacion)): ?>
                        <button type="submit"
                                class="bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-8 rounded-full shadow transition">
                            Actualizar medicación
                        </button>

                        <a href="<?php echo e(route('tratamiento.show', $medicacion->id_tratamiento)); ?>"
                        class="bg-gray-300 hover:bg-gray-400 text-black font-semibold py-3 px-8 rounded-full shadow transition">
                            Cancelar
                        </a>
                    <?php else: ?>
                        <a href="<?php echo e(route('tratamiento.show', $tratamiento->id_tratamiento)); ?>"
                        class="bg-red-500 hover:bg-red-700 text-white font-bold py-3 px-8 rounded-full shadow transition">
                            Cancelar
                        </a>

                        <button type="submit" name="accion" value="add"
                                class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 px-8 rounded-full shadow transition">
                            Guardar y añadir otra
                        </button>

                        <button type="submit" name="accion" value="done"
                                class="bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-8 rounded-full shadow transition">
                            Guardar y finalizar
                        </button>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.registro', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\a23elenaqb\medicapp\resources\views/medicacion/create.blade.php ENDPATH**/ ?>