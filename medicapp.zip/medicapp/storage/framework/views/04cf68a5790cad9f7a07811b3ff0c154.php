<?php $__env->startSection('title', 'Perfiles – MedicApp'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex flex-col items-center px-10 pt-10">
    <h2 class="text-3xl font-bold mb-2 text-center">Perfiles</h2>
    <p class="text-center text-white mb-10">Seleccione en el desplegable amarillo el perfil que desea gestionar</p>

    <?php if(!$perfilActivo): ?>
        <div class="text-white">
            <p>No tienes perfiles activos.</p>
            <a href="<?php echo e(route('perfil.create', ['fromDashboard' => 1])); ?>" class="underline text-yellow-300">
                Crear primer perfil
            </a>
        </div>
    <?php else: ?>
        <?php
            $soyInvitado = Auth::user()->perfiles()
                ->wherePivot('rol_en_perfil', 'invitado')
                ->where('perfil.id_perfil', $perfilActivo->id_perfil)
                ->exists();
        ?>

        <div class="grid grid-cols-1 lg:grid-cols-2 items-start gap-12 w-full max-w-6xl">
            <div class="space-y-6">
                <div class="bg-transparent border-2 border-gray-500 rounded-lg p-8 w-full text-white">
                    <h3 class="text-xl font-bold mb-6 text-center text-yellow-200">Datos del paciente</h3>

                    <form id="form-perfil" method="POST" action="<?php echo e(route('perfil.update', $perfilActivo->id_perfil)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="mb-6">
                            <label class="block mb-2" for="nombre_paciente">Nombre</label>
                            <input type="text" id="nombre_paciente" name="nombre_paciente"
                                class="w-full p-2 rounded text-black"
                                value="<?php echo e(old('nombre_paciente', $perfilActivo->nombre_paciente)); ?>" required>
                        </div>

                        <div class="mb-6">
                            <label class="block mb-2" for="fecha_nacimiento">Fecha de nacimiento</label>
                            <input type="date" id="fecha_nacimiento" name="fecha_nacimiento"
                                class="w-full p-2 rounded text-black"
                                value="<?php echo e(old('fecha_nacimiento', $perfilActivo->fecha_nacimiento)); ?>" required>
                        </div>

                        <div>
                            <label class="block mb-2" for="sexo">Género</label>
                            <select id="sexo" name="sexo" class="w-full p-2 rounded text-black" required>
                                <option value="F" <?php if($perfilActivo->sexo === 'F'): echo 'selected'; endif; ?>>Mujer</option>
                                <option value="M" <?php if($perfilActivo->sexo === 'M'): echo 'selected'; endif; ?>>Hombre</option>
                                <option value="NB" <?php if($perfilActivo->sexo === 'NB'): echo 'selected'; endif; ?>>No binario</option>
                                <option value="O" <?php if($perfilActivo->sexo === 'O'): echo 'selected'; endif; ?>>Otro</option>
                            </select>
                        </div>
                    </form>

                    <div class="mt-8 flex items-center justify-center gap-4">
                        <button form="form-perfil"
                                class="bg-green-500 hover:bg-green-600 text-black font-bold px-6 py-3 rounded-full shadow">
                            Guardar cambios
                        </button>

                        <form method="POST" action="<?php echo e(route('perfil.destroy', $perfilActivo->id_perfil)); ?>"
                              onsubmit="return confirm('¿Está seguro de que desea eliminar este perfil? Esta acción no se puede deshacer.');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit"
                                    class="bg-red-600 hover:bg-red-700 text-white font-bold px-6 py-3 rounded-full shadow">
                                Eliminar perfil
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <?php if($perfilActivo && (($esPremium && $esPropietario) || $soyInvitado)): ?>
                <div class="bg-[#0C1222] border border-gray-500 rounded-xl p-6 text-white">
                    <h3 class="text-yellow-200 font-bold text-xl mb-4">Accesos compartidos</h3>

                    <p class="mb-4">
                        Usuario creador:
                        <span class="text-gray-300 font-mono"><?php echo e($creador?->email ?? Auth::user()->email); ?></span>
                    </p>

                    <?php if(($esPremium && $esPropietario) && $pendientes->count()): ?>
                        <div class="mb-4">
                            <h4 class="font-semibold mb-2">Invitaciones pendientes</h4>
                            <ul class="list-disc ml-5 text-sm text-gray-300">
                                <?php $__currentLoopData = $pendientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($p->email); ?> <?php if($p->expires_at): ?>(caduca: <?php echo e($p->expires_at->format('d/m/Y')); ?>)<?php endif; ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <div class="overflow-x-auto mb-6">
                        <table class="min-w-full border border-gray-600">
                            <thead class="bg-blue-200 text-[#0C1222]">
                                <tr>
                                    <th class="px-4 py-2 text-left">USUARIOS INVITADOS</th>
                                    <th class="px-4 py-2 text-left">QUITAR</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $invitados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr class="border-t border-gray-600">
                                        <td class="px-4 py-3"><?php echo e($inv->email); ?></td>
                                        <td class="px-4 py-3">
                                            <?php if($esPremium && $esPropietario): ?>
                                                <form method="POST" action="<?php echo e(route('perfil.miembros.destroy', [$perfilActivo->id_perfil, $inv->id_usuario])); ?>"
                                                    onsubmit="return confirm('¿Quitar acceso a <?php echo e($inv->email); ?>?');">
                                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="bg-red-600 hover:bg-red-700 text-white font-bold px-4 py-2 rounded-full">✕</button>
                                                </form>
                                            <?php else: ?>
                                                <span class="text-gray-400">—</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr class="border-t border-gray-600">
                                        <td class="px-4 py-3 text-gray-300" colspan="2">Sin invitados.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <?php if($esPremium && $esPropietario): ?>
                        <form method="POST" action="<?php echo e(route('perfil.invitaciones.store', $perfilActivo->id_perfil)); ?>" class="flex gap-3 items-center">
                            <?php echo csrf_field(); ?>
                            <input type="email" name="email" placeholder="correo@ejemplo.com" class="flex-1 px-4 py-2 rounded text-black" required>
                            <button type="submit" class="bg-green-500 hover:bg-green-600 text-black font-bold px-4 py-2 rounded-full">Invitar</button>
                        </form>

                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-400 mt-3"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php if(session('success')): ?> <p class="text-green-400 mt-3"><?php echo e(session('success')); ?></p> <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\a23elenaqb\medicapp\resources\views/perfil/index.blade.php ENDPATH**/ ?>