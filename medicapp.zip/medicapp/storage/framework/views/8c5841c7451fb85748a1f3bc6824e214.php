<footer class="w-full bg-[#3F423D] text-white text-sm text-center py-4">
    <a href="/aviso-legal" class="hover:underline">Aviso legal</a>
    &nbsp;&middot;&nbsp;
    <a href="/politica-privacidad" class="hover:underline">Política de privacidad</a>
    &nbsp;&middot;&nbsp;
    <a href="/politica-cookies" class="hover:underline">Política de cookies</a>
</footer>

<?php /**PATH C:\xampp\htdocs\a23elenaqb\medicapp\resources\views/components/footer.blade.php ENDPATH**/ ?>