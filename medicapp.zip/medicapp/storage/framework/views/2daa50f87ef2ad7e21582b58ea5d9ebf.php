<?php $__env->startSection('title', 'Nuevo perfil – MedicApp'); ?>

<?php $__env->startSection('content'); ?>
<main class="flex-grow flex items-center justify-center">
    <div class="w-full max-w-2xl px-8">
        <h2 class="text-3xl font-bold text-center mb-10">Datos del paciente</h2>
        <?php if($errors->any()): ?>
            <div class="mb-6 p-4 rounded bg-red-100 text-red-800">
                <ul class="list-disc ml-5">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('perfil.store')); ?>" class="space-y-6">
            <?php echo csrf_field(); ?>
            <div>
                <label for="nombre_paciente" class="block mb-1 text-lg">Nombre</label>
                <input id="nombre_paciente" name="nombre_paciente" type="text" required
                       value="<?php echo e(old('nombre_paciente')); ?>"
                       class="w-full px-4 py-3 border border-gray-300 rounded text-[#0C1222] focus:outline-none focus:ring-2 focus:ring-blue-400">
            </div>
            <div>
                <label for="fecha_nacimiento" class="block mb-1 text-lg">Fecha de nacimiento</label>
                <input id="fecha_nacimiento" name="fecha_nacimiento" type="date" required
                       min="1900-01-01" max="<?php echo e(\Carbon\Carbon::now()->toDateString()); ?>"
                       value="<?php echo e(old('fecha_nacimiento')); ?>"
                       class="w-full px-4 py-3 border border-gray-300 rounded text-[#0C1222] focus:outline-none focus:ring-2 focus:ring-blue-400">
            </div>
            <div>
                <label for="sexo" class="block mb-1 text-lg">Género</label>
                <select id="sexo" name="sexo" required
                        class="w-full px-4 py-3 border border-gray-300 rounded text-[#0C1222] bg-white focus:outline-none focus:ring-2 focus:ring-blue-400">
                    <?php $sexoOld = old('sexo'); ?>
                    <option value="F" <?php echo e($sexoOld==='F' ? 'selected' : ''); ?>>Mujer</option>
                    <option value="M" <?php echo e($sexoOld==='M' ? 'selected' : ''); ?>>Hombre</option>
                    <option value="NB" <?php echo e($sexoOld==='NB' ? 'selected' : ''); ?>>No binario</option>
                    <option value="O" <?php echo e($sexoOld==='O' ? 'selected' : ''); ?>>Otro</option>
                </select>
            </div>
            <div>
                <label for="causa" class="block mb-1 text-lg">Causa de tratamiento</label>
                <input id="causa" name="causa" type="text" required maxlength="150"
                       value="<?php echo e(old('causa')); ?>"
                       class="w-full px-4 py-3 border border-gray-300 rounded text-[#0C1222] focus:outline-none focus:ring-2 focus:ring-blue-400">
            </div>
            <div class="text-center mt-8">
                <button type="submit"
                        class="bg-yellow-300 text-[#0C1222] font-bold text-lg px-10 py-3 rounded-full hover:bg-yellow-200 transition">
                    Crear perfil
                </button>
            </div>
        </form>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\a23elenaqb\medicapp\resources\views/perfil/create.blade.php ENDPATH**/ ?>