@extends('layouts.app')

@section('content')
<div class="container mt-4">
    <h2 class="mb-4 text-white">Citas médicas</h2>

    <!-- Filtro -->
    <div class="mb-3">
        <input type="text" class="form-control" placeholder="Filtre por fecha, hora, especialista-lugar, motivo o creador">
    </div>

    <!-- Tabla -->
    <table class="table table-bordered table-dark table-striped text-white">
        <thead class="table-primary text-center">
            <tr>
                <th>FECHA</th>
                <th>HORA</th>
                <th>ESPECIALISTA - LUGAR</th>
                <th>MOTIVO</th>
                <th>CREADO POR</th>
                <th>EDITAR</th>
            </tr>
        </thead>
        <tbody>
            <!-- Aquí irán dinámicamente las citas -->
        </tbody>
    </table>

    <!-- Botones laterales (temporalmente aquí para pruebas) -->
    <div class="position-fixed" style="right: 30px; top: 50%; transform: translateY(-50%);">
        <button class="btn btn-success rounded-circle mb-3" style="width: 60px; height: 60px;">
            <span class="fs-3">+</span>
        </button>
        <img src="{{ asset('img/google-sync.png') }}" alt="Sync Google Calendar" style="width: 60px; height: 60px;">
    </div>
</div>
@endsection
